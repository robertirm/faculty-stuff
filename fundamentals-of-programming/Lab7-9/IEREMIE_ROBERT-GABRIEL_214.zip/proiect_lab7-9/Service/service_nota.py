from Domain.entitate_nota import Nota
from Domain.validator import ValNota
from Domain.entitate_student import Student
from Domain.entitate_disciplina import Disciplina
from Repository.repo_nota import RepoNota
from Repository.repo_disciplina import RepoDisciplina
from Repository.repo_student import RepoStudent


class SrvNota:
    def __init__(self, rep, val):
        self.rep = rep
        self.val = val

    def add(self, stud):
        """
        Adauga o nota in lista de note
        :param disc: nota
        :exception RepoNotaExceptie : o nota cu un id deja existent
        """
        self.rep.add(stud)

    def size(self):
        """
        Numarul de note din memorie
        :return: int
        """
        return self.rep.size()

    def all(self):
        """
        Lista cu toate notele
        :return: list
        """
        return self.rep.all()

    def delete(self, id):
        """
        sterge o nota cu id-ul precizat
        :param id: string
        :return: list
        """
        self.rep.delete(id)

    def update(self, idn, ids, idd, nota):
        """
        Actualizeaza o nota
        :param idn: id-ul notei
        :param ids: id-ul studentului
        :param idd: id-ul disciplinei
        :param nota: valoarea notei
        :return: se actualizeaza nota respectiva
        """
        self.rep.update(idn, ids, idd, nota)

    def sortare_dupa_nume(self, disc):
        """
        Sorteaza notele pentru o disciplina dupa numele studentilor , in ordine alfabetica
        :param disc: disciplina precizata (string)
        :return: list
        """
        srt = self.rep.all_by_disc(disc)
        n = len(srt)
        for i in range(0, n - 1):
            for j in range(0, n - i - 1):
                if srt[j].get_ids() > srt[j + 1].get_ids():
                    srt[j], srt[j + 1] = srt[j + 1], srt[j]
        return srt

    def sortare_dupa_nota(self, disc):
        """
        Sorteaza notele pentru o disciplina dupa valoarea notei , in ordine descrescatoare
        :param disc: disciplina precizata (string)
        :return: list
        """
        srt = self.rep.all_by_disc(disc)
        n = len(srt)
        for i in range(0, n - 1):
            for j in range(0, n - i - 1):
                if float(srt[j].get_nota()) < float(srt[j + 1].get_nota()):
                    srt[j], srt[j + 1] = srt[j + 1], srt[j]
        return srt

    def procent(self):
        '''
        Selecteaza primii 20% dintre studenti dupa media notelor ordonate crescator
        :return:
        '''
        medii = self.rep.total_medii()
        n = len(medii)
        for i in range(0, n):
            for j in range(0, n - i - 1):
                if medii[j][1] < medii[j + 1][1]:
                    medii[j], medii[j + 1] = medii[j + 1], medii[j]
        n = int(round(n * 0.2))
        medii_perc = medii[:n]
        return medii_perc

    def media_disc(self, id_d):
        """
        Functia afla nr de studenti si 'media disciplinei' pentru o disciplina specificata
        :param id_d: id-ul disciplinei (string)
        :return: nr_studenti - int , media - float
        """
        medii = self.rep.medii_for_disc(id_d)
        suma = 0
        k = 0
        for m in medii:
            if m[1] != 0:
                suma = suma + m[1]
                k = k + 1

        if k == 0:
            media = 0
        else:
            media = suma / k

        return k, media

#   1 7.8 111 77
#   2 6.9 222 77
#   3 8.99 111 77

def test_sercive_n():
    rs = RepoStudent()
    rd = RepoDisciplina()
    rep = RepoNota(rs, rd)
    val = ValNota()
    rs.add(Student('11', 'andrei'))
    rs.add(Student('12', 'ana'))
    rs.add(Student('13', 'vasile'))
    rd.add(Disciplina('1', 'mate', 'pitagora'))
    rep.add(Nota('01', '11', '1', '5.30'))
    rep.add(Nota('02', '12', '1', '4.30'))
    rep.add(Nota('03', '13', '1', '8.30'))
    rep.add(Nota('04', '11', '1', '9.30'))
    srv = SrvNota(rep, val)
    assert srv.procent() == [['13', 8.30]]
    assert srv.sortare_dupa_nume('1')[0].ids == 'ana'
    assert srv.sortare_dupa_nota('1')[0].ids == 'andrei'

test_sercive_n()