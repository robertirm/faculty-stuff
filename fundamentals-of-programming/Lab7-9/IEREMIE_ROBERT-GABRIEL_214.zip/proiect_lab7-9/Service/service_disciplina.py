from Repository.repo_disciplina import RepositoryException1, RepoDisciplina
from Domain.entitate_disciplina import Disciplina
from Domain.validator import ValDisciplinia


class SrvDisciplina:
    def __init__(self, rep, val):
        self.rep = rep
        self.val = val

    def add(self, stud):
        """
        Adauga o disciplina in lista de discipline
        :param disc: Disciplina
        :exception RepoDisciplinaExceptie : o disciplina cu un id deja existent
        """
        self.rep.add(stud)

    def size(self):
        """
        Numarul de discipline din memorie
        :return: int
        """
        return self.rep.size()

    def all(self):
        """
        Lista cu toate disciplinele
        :return: list
        """
        return self.rep.all()

    def delete(self, id):
        """
        sterge o disciplina cu id-ul precizat
        :param id: string
        :return: list
        """
        self.rep.delete(id)

    def update(self, idi, id, nume, prof):
        '''
        Actualizarea unei discipline
        :param idi: id-ul disciplinei curente
        :param id:  id nou
        :param nume: numele nou
        :param prof: profesorul nou
        :return:
        '''
        self.rep.update(idi, id, nume, prof)

    def cautare_id(self, id):
        """
        Cautare a unei discipline dupa ID
        :param id: string
        :return: lista cu disciplinele cautate
        """
        lista = self.all()
        rez = []
        for el in lista:
            if el.get_id() == id:
                rez.append(el)
        return rez

    def cautare_nume(self, nume):
        """
        Cautare a unei discipline dupa nume
        :param nume: string
        :return: lista cu disciplinele cautate
        """
        lista = self.all()
        rez = []
        for el in lista:
            if el.get_nume() == nume:
                rez.append(el)
        return rez

    def cautare_prof(self, prof):
        """
        Cautare a unei discipline dupa profesor
        :param prof: string
        :return: lista cu disciplinele cautate
        """
        lista = self.all()
        rez = []
        for el in lista:
            if el.get_profesor() == prof:
                rez.append(el)
        return rez



def teste():
    val = ValDisciplinia()
    rep = RepoDisciplina()
    srv = SrvDisciplina(rep, val)
    d = Disciplina('1', 'analiza', 'berinde')
    srv.add(d)
    assert srv.size() == 1
    l1 = srv.cautare_id('1')
    assert len(l1) == 1
    l1 = srv.cautare_nume('analiza')
    assert len(l1) == 1
    l1= srv.cautare_prof('berinde')
    assert len(l1) == 1

teste()
