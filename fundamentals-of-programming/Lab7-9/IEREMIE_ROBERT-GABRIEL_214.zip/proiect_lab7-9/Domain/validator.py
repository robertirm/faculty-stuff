from Domain.entitate_student import Student
from Domain.entitate_nota import Nota
from Domain.entitate_disciplina import Disciplina
from Repository.repo_disciplina import RepoDisciplina
from Repository.repo_student import RepoStudent

class ValidatorException(BaseException):
    def __init__(self, errors):
        self.errors = errors

    def get_errors(self):
        return self.errors

class ValStudent:
    '''
     validare studenti
    '''
    def validate(self, st):
        errors = []
        if st.get_id() == '':
            errors.append("ID-ul nu poate fi gol!")
        if st.get_nume() == '':
            errors.append("Numele nu poate fi gol!")
        if len(errors) > 0:
            raise ValidatorException(errors)


def test_valstud():
    '''
    teste pentru validare studenti
    :return:
    '''
    stud = Student("", "")
    val = ValStudent()
    try:
        val.validate(stud)
        assert False
    except ValidatorException as ex:
        assert len(ex.get_errors()) == 2

    stud = Student("234", "Ion Ion")
    try:
        val.validate(stud)
        assert True
    except ValidatorException as ex:
        assert False


class ValDisciplinia():
    '''
     validare disciplina
    '''
    def validate(self, ds):
        errors = []
        if ds.get_id() == '':
            errors.append("ID-ul nu poate fi gol!")
        if ds.get_nume() == '':
            errors.append("Numele nu poate fi gol!")
        if ds.get_profesor() == '':
            errors.append("Profesorul nu poate sa fie gol!")
        if len(errors) > 0:
            raise ValidatorException(errors)


def test_valdisc():
    val = ValDisciplinia()
    d = Disciplina("1", "Educatie fizica", "Maradona")

    try:
        val.validate(d)
        assert True
    except ValidatorException as ex:
        assert False

    d = Disciplina("2", "", "")
    try:
        val.validate(d)
        assert False
    except ValidatorException as ex:
        assert len(ex.get_errors()) == 2


class ValNota():
    '''
        validare nota
    '''
    def validate(self, nota):
        errors = []
        if nota.get_ids() == '':
            errors.append("Id-ul studentului nu poate fi liber!")
        if nota.get_idd() == '':
            errors.append("Id-ul disciplinei nu poate fi liber!")
        if nota.get_idn() == '':
            errors.append("Id-ul notei nu poate fi liber!")
        if nota.get_nota() == '':
            errors.append("Nota nu poate fi goala!")
        try:
            notanr = float(nota.get_nota())
            if notanr <= 0 or notanr > 10:
                raise ValidatorException(["val nota"])
        except ValueError as msg:
            errors.append("value")
        if len(errors) > 0:
            raise ValidatorException(errors)


def test_valnota():
    val = ValNota()
    nota = Nota("135", "1", "135.1.1", "8.50")
    try:
        val.validate(nota)
        assert True
    except ValidatorException as ex:
        assert False

    nota = Nota("", "", "", "6.25")
    try:
        val.validate(nota)
        assert False
    except ValidatorException as ex:
        assert len(ex.get_errors()) == 3


test_valnota()
test_valdisc()
test_valstud()
