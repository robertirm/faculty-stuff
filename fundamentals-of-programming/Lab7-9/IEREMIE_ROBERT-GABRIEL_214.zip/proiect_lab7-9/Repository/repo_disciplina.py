from Domain.entitate_disciplina import Disciplina


class RepositoryException1(BaseException):
    pass


class RepoDisciplina:
    def __init__(self):
        """
        Salveaza studentii in memorie
        """
        self.lista = []

    def add(self, disc):
        """
        Adauga o disciplina in lista de discipline
        :param disc: Disciplina
        :exception RepoDisciplinaExceptie : o disciplina cu un id deja existent
        """
        if disc in self.lista:
            raise RepositoryException1()
        else:
            self.lista.append(disc)

    def size(self):
        """
        Numarul de discipline din memorie
        :return: int
        """
        return len(self.lista)

    def all(self):
        """
        Lista cu toate disciplinele
        :return: list
        """
        return list(self.lista)

    def delete(self, id):
        """
        sterge o disciplina cu id-ul precizat
        :param id: string
        :return: list
        """
        for i, d in enumerate(self.lista):
            if d.id == id:
                del self.lista[i]

    def update(self, idi, id, nume,prof):
        '''
        Actualizarea unei discipline
        :param idi: id-ul disciplinei curente
        :param id:  id nou
        :param nume: numele nou
        :param prof: profesorul nou
        :return:
        '''
        for i, d in enumerate(self.lista):
            if d.id == idi:
                d.set_id(id)
                d.set_nume(nume)
                d.set_profesor(prof)


def test_repo_discipline():
    d1 = Disciplina("1", "Educatie Fizica", "Gheorghe Hagi")
    rep = RepoDisciplina()
    assert rep.size() == 0
    rep.add(d1)
    assert rep.size() == 1
    d2 = Disciplina("2", "Muzica", "Lino Golden")
    rep.add(d2)
    assert rep.size() == 2
    d3 = Disciplina("2", "Desen", "Grigorescu")
    try:
        rep.add(d3)
        assert False
    except RepositoryException1 as ex:
        pass

    rep.delete('2')
    assert rep.size() == 1

test_repo_discipline()