from Domain.entitate_nota import Nota
from Repository.repo_disciplina import RepoDisciplina, Disciplina
from Repository.repo_student import RepoStudent,Student


class RepositoryException3(Exception):
    pass


class RepopsitoryStdDisc(Exception):
    pass


class RepoNota:
    def __init__(self, reps, repd):
        """
        Salveaza studentii in memorie
        """
        self.lista = []
        self.rep_s = reps
        self.rep_d = repd

    def add(self, nota):
        """
        Adauga o nota in lista de nota
        :param nota: Nota
        :exception RepoNotaExceptie : o nota cu un id deja existent
        """
        ok1 = 0
        ok2 = 0
        for obj in self.rep_s.all():
            if obj.get_id() == nota.get_ids():
                ok1 = 1

        for obj in self.rep_d.all():
            if obj.get_id() == nota.get_idd():
                ok2 = 1 

        if ok1 == 0 or ok2 == 0:
            raise RepopsitoryStdDisc()
        if nota in self.lista:
            raise RepositoryException3()
        else:
            self.lista.append(nota)

    def size(self):
        """
        Numarul de studenti din memorie
        :return: int
        """
        return len(self.lista)

    def all(self):
        """
        Lista cu toate notele
        :return: list
        """
        return list(self.lista)

    def get_all_ids_of_students(self):
        """
        Functie ce returzeaza o lista cu id-urile tuturor studentilor
        :return:list of strings
        """
        ids = []
        for st in self.rep_s.all():
            ids.append(st.get_id())
        return ids

    def get_all_ids_of_disc(self):
        """
        Functie ce returzeaza o lista cu id-urile tututor disciplinelor
        :return:list of strings
        """
        ids = []
        for d in self.rep_d.all():
            ids.append(d.get_id())
        return ids

    def all_by_disc(self, disc):
        """
        Functie ce returneaza toate notele de la o disciplina
        :param disc: id-ul disciplinei precizate
        :return: lista cu notele cerute
        """
        lista = []
        for obj in self.lista:
            if obj.get_idd() == disc:
                nume = ''
                disciplina = ''
                for st in self.rep_s.all():
                    if st.get_id() == obj.get_ids():
                        nume = st.get_nume()
                for d in self.rep_d.all():
                    if d.get_id() == obj.get_idd():
                        disciplina = d.get_nume()
                s = Nota(obj.get_idn(), nume, disciplina, obj.get_nota())
                lista.append(s)
        return lista

    def medii_for_disc(self, disc):
        """
        Functie ce returneaza media fiecarui student pentru disciplina data
        :param disc:
        :return:
        """
        studs = self.get_all_ids_of_students()
        medii = []
        for st in studs:
            k = 0
            s = 0
            for nota in self.lista:
                if nota.get_ids() == st and nota.get_idd() == disc:
                    k = k + 1
                    s = s + float(nota.get_nota())
            if k != 0:
                m = s/k
            else:
                m = 0
            medii.append([st, m])
        return medii

    def total_medii(self):
        '''
        Functie ce returneaza media tuturor notelor pentru fiecare student
        :return:
        '''
        studs = self.get_all_ids_of_students()
        medii = []
        for st in studs:
            k = 0
            s = 0
            for nota in self.lista:
                if nota.get_ids() == st:
                    k = k + 1
                    s = s + float(nota.get_nota())
            if k != 0:
                m = s/k
            else:
                m = 0
            medii.append([st, m])
        return medii


def test_rep_note():
    rs = RepoStudent()
    rs.add(Student('1', 'andrei'))
    rs.add(Student('5', 'ana'))
    rd = RepoDisciplina()
    rd.add(Disciplina("135", "analiza", "berinde"))
    rd.add(Disciplina("522", "algebra", "modoi"))
    rep = RepoNota(rs, rd)
    n1 = Nota("1", "1", "135", "10.00")
    assert rep.size() == 0
    rep.add(n1)
    assert rep.size() == 1
    n2 = Nota("2", "1", "522", "8.25")
    rep.add(n2)
    assert rep.size() == 2
    n3 = Nota("2", "5", "522", "8.50")
    try:
        rep.add(n3)
        assert False
    except RepositoryException3 as ex:
        pass
    assert rep.get_all_ids_of_students() == ['1', '5']
    assert rep.get_all_ids_of_disc() == ['135', '522']

test_rep_note()
