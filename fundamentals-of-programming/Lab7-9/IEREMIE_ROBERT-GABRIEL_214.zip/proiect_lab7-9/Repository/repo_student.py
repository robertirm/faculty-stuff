from Domain.entitate_student import Student


class RepositoryException2(Exception):
    pass


class RepoStudent:
    def __init__(self):
        """
        Salveaza studentii in memorie
        """
        self.lista = []

    def add(self, stud):
        """
        Adauga un student in lista de studenti
        :param stud: Student
        """
        if stud in self.lista:
            raise RepositoryException2()
        else:
            self.lista.append(stud)

    def size(self):
        """
        Numarul de studenti din memorie
        :return: int
        """
        return len(self.lista)

    def all(self):
        """
        Lista cu toti studentii
        :return: list
        """
        return self.lista

    def delete(self, id):
        """
        sterge un student cu id-ul precizat
        :param id: string
        :return: list
        """
        for i, st in enumerate(self.lista):
            if st.get_id() == id:
                del self.lista[i]

    def update(self, idi, id, nume):
        '''
        Actualizarea unui student
        :param idi: id-ul studentului curent
        :param id:  id nou
        :param nume: numele nou
        :return:
        '''
        for i, st in enumerate(self.lista):
            if st.id == idi:
                st.set_id(id)
                st.set_nume(nume)


def test_repstudent():
    st = Student("1", "Andrei")
    rep = RepoStudent()
    assert rep.size() == 0
    rep.add(st)
    assert rep.size() == 1
    st2 = Student("2", "Ana")
    rep.add(st2)
    assert rep.size() == 2
    st3 = Student("2", "Marcel")
    try:
        rep.add(st3)
        assert False
    except RepositoryException2 as ex:
        pass
    rep.delete('2')
    assert rep.size() == 1
    st4 = Student('1', 'vasile')


test_repstudent()
