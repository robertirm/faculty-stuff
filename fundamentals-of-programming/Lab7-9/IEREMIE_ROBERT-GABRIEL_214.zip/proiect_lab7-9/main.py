from UI.console import Consola
from Repository.repo_student import RepoStudent
from Repository.repo_disciplina import RepoDisciplina
from Repository.repo_nota import RepoNota
from Domain.validator import ValNota, ValStudent, ValDisciplinia
from Service.service_disciplina import SrvDisciplina
from Service.service_student import SrvStudent
from Service.service_nota import SrvNota

rep_s = RepoStudent()
rep_d = RepoDisciplina()
rep_n = RepoNota(rep_s, rep_d)

val_s = ValStudent()
val_d = ValDisciplinia()
val_n = ValNota()

srv_s = SrvStudent(rep_s, val_s)
srv_d = SrvDisciplina(rep_d, val_d)
srv_n = SrvNota(rep_n, val_n)

ui = Consola(srv_s, srv_d, srv_n)

ui.meniu()
